<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="Content-Style-Type" content="text/css">
  <title></title>
  <meta name="Generator" content="Cocoa HTML Writer">
  <meta name="CocoaVersion" content="2487.3">
  <style type="text/css">
    p.p1 {margin: 0.0px 0.0px 0.0px 0.0px}
    p.p2 {margin: 0.0px 0.0px 0.0px 0.0px; min-height: 14.0px}
    span.s1 {font: 12.0px Helvetica}
  </style>
</head>
<body>
<p class="p1"><span class="s1">const posters = [</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">    </span>{</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>title: "WALL-E",</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>year: 2008,</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>img: "images/wall-e.jpg",</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>price: "50.00",</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>shopifyEmbed: `&lt;iframe src="https://yourshopifystore.com/products/wall-e?view=buy_button" width="100%" height="250px" frameborder="0"&gt;&lt;/iframe&gt;`</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">    </span>},</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">    </span>{</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>title: "Star Wars",</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>year: 1977,</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>img: "images/star-wars.jpg",</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>price: "75.00",</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>shopifyEmbed: `&lt;iframe src="https://yourshopifystore.com/products/star-wars?view=buy_button" width="100%" height="250px" frameborder="0"&gt;&lt;/iframe&gt;`</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">    </span>}</span></p>
<p class="p1"><span class="s1">];</span></p>
<p class="p2"><span class="s1"></span><br></p>
<p class="p1"><span class="s1">function displayPosters() {</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">    </span>const gallery = document.getElementById("posterGallery");</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">    </span>posters.forEach(poster =&gt; {</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>gallery.innerHTML += `</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">            </span>&lt;div class="poster-card"&gt;</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">                </span>&lt;img src="${poster.img}" alt="${poster.title}"&gt;</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">                </span>&lt;h3&gt;${poster.title} (${poster.year})&lt;/h3&gt;</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">                </span>&lt;p&gt;Price: $${poster.price}&lt;/p&gt;</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">                </span>&lt;div class="buy-button-container"&gt;</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">                    </span>${poster.shopifyEmbed}</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">                </span>&lt;/div&gt;</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">            </span>&lt;/div&gt;</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">        </span>`;</span></p>
<p class="p1"><span class="s1"><span class="Apple-converted-space">    </span>});</span></p>
<p class="p1"><span class="s1">}</span></p>
<p class="p2"><span class="s1"></span><br></p>
<p class="p1"><span class="s1">displayPosters();</span></p>
</body>
</html>
